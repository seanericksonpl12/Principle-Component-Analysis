# Principle-Component-Analysis
Decompose Images into lower dimensions and transpose them back to an image
